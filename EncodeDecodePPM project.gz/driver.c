/*****************************************************************************
* Name: Marshal Rice
* Username: mrice4
* CUID: C10281548
* Class: CPSC 2310-002
* Instructor: Yvon Feater
* File Description: DRIVER.C
*   Driver.c is the file that holds the main function, which will be the
*   central calling function that calls other functions. Together, this file
*   carries out encryptions and decryptions of ppm files by changing the
*   beginning of a ppm file's pixel data to match binary number patterns
*   of ASCII values. Combining all ASCII value representations will equate
*   to the message that needs decoding or encrypting, which will be given
*   from input.
*****************************************************************************/
#include "ppm.h"
#include "EncodeDecode.h"
int main(int argc, char** argv){
  assert(argc == 3);
  FILE* in = fopen(argv[1], "r");
  FILE* out = fopen(argv[2],"w");
  assert(in != NULL);
  menu();
  char* message = NULL;
  message = newMessage(message);
  encode(message, in, out);
  decode(in);

  fclose(in);
  fclose(out);

  free(message);
  return 0;
}
