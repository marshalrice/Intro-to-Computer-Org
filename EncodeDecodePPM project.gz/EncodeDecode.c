#include "EncodeDecode.h"
#include "ppm.h"

//prints the menu for driver.c
void menu(){
  printBoarder();
  fprintf(stdout, "*\n");
  fprintf(stdout, "*\tWelcome to the Image Encryption/Decryption Program\n");
  fprintf(stdout, "*\n");
  printBoarder();
}

//prints a boarder of asterisks
void printBoarder(){
  for(int i = 0; i < 80; ++i){
    fprintf(stdout, "*");
  }
  printf("\n");
}

//Gets the new message if any for encode function
char* newMessage(char* message){
  //variable declarations
  char response;
  //printing prompt
  fprintf(stdout, "\tWould you like to keep the decoded message or add a"
  " new message to the encoded image? (K/k/A/a)\n");
  fprintf(stdout, "------> ");
  //gets response
  scanf("%c", &response);
  //checks the response's validity
  while(!(response == 'K' || response == 'k' || response == 'A' ||
  response == 'a')){
    fprintf(stdout, "\tERROR! Invalid input. Please try again. (Y/y/N/n)\n");
    fprintf(stdout, "------> ");
    scanf("\n%c", &response);
  }
  //asks for the new message if requested
  if(response == 'A' || response == 'a'){
    fprintf(stdout, "Type new encoded message here -----> ");
    message = (char*)malloc(500 * sizeof(char));
    scanf("\n%[^\n]s",message);
    message = (char*)realloc(message, strlen(message));
    fprintf(stdout, "Thank you for the new message!\n");
    return message;
  }
  if(response == 'K' || response == 'k'){
    message = (char*)realloc(message,80*sizeof(char));
    message = "Hello Class! This has been a great semester."
  " I hope you enjoyed this assignment.";
  }
  return message;
}
void decode(FILE* in){
  rewind(in);
  header* header = readHeader(in);
  getMessage(in);
  free(header);
  rewind(in);
  //return message;
}
//This code takes two files and a message and copies over most of each file
//execpt the first few bits are encrypted with the message given.
void encode(char* message, FILE* in, FILE* out){
  //sets the input file back to the beginning
  rewind(in);
  //gets header.
  header* decodedHeader = readHeader(in);
  //writes new header to out file
  writeHeadertoPPM(out, decodedHeader);
  //declaring variables and allocating memory
  pixel* temp = (pixel*)malloc(sizeof(pixel));
  int i = 0;
  int asciiVal;
  int remainder;
  int index = 0;
  int binary[strlen(message)][9];
  //gets the entire binary sequence of a message
  while(message[i] != '\0'){
    asciiVal = message[i];
    while(asciiVal > 0){
      remainder = asciiVal % 2;
      binary[i][index] = remainder;
      asciiVal = asciiVal / 2;
      ++index;
    }
    index = 0;
    ++i;
  }
  //scans each three pixels and changes them all to suit the encryption
  //of the message
  for(int i = 0; i < strlen(message);++i){
    fscanf(in, "%c%c%c", &temp[0].r, &temp[0].g, &temp[0].b);
    fscanf(in, "%c%c%c", &temp[1].r, &temp[1].g, &temp[1].b);
    fscanf(in, "%c%c%c", &temp[2].r, &temp[2].g, &temp[2].b);
    fprintf(out, "%c", temp[0].r - (temp[0].r % 10) + binary[i][8]);
    fprintf(out, "%c", temp[0].g - (temp[0].g % 10) + binary[i][7]);
    fprintf(out, "%c", temp[0].b - (temp[0].b % 10) + binary[i][6]);
    fprintf(out, "%c", temp[1].r - (temp[1].r % 10) + binary[i][5]);
    fprintf(out, "%c", temp[1].g - (temp[1].g % 10) + binary[i][4]);
    fprintf(out, "%c", temp[1].b - (temp[1].b % 10) + binary[i][3]);
    fprintf(out, "%c", temp[2].r - (temp[2].r % 10) + binary[i][2]);
    fprintf(out, "%c", temp[2].g - (temp[2].g % 10) + binary[i][1]);
    fprintf(out, "%c", temp[2].b - (temp[2].b % 10) + binary[i][0]);
    }
    //transfers the rest of the file over.
  while(in != NULL){
    fscanf(in, "%c%c%c", &temp[0].r, &temp[0].g, &temp[0].b);
    fprintf(out, "%c%c%c",temp[0].r, temp[0].g, temp[0].b);
  }
}

void getMessage(FILE* in){
  unsigned char binaryLetter[9];
  int asciiVal = 0;
  int bitPos = 0;
  //char* message = NULL;
  //int len = 0;
  pixel* letter = (pixel*)malloc(3*sizeof(pixel));
  printf("\nThe decoded message is: ");
  fscanf(in, "%c%c%c", &letter[0].r, &letter[0].g, &letter[0].b);
  fscanf(in, "%c%c%c", &letter[1].r, &letter[1].g, &letter[1].b);
  fscanf(in, "%c%c%c", &letter[2].r, &letter[2].g, &letter[2].b);
  //printf("%c%c%c ",letter[0].r, letter[0].g, letter[0].b);
  //printf("%c%c%c ",letter[1].r, letter[1].g, letter[1].b);
  //printf("%c%c%c",letter[2].r, letter[2].g, letter[2].b);
  while(!(letter[0].r %10 ==0 && letter[0].g %10 ==0 && letter[0].b %10 ==0
       && letter[1].r %10 ==0 && letter[1].g %10 ==0 && letter[1].b %10 ==0
       && letter[2].r %10 ==0 && letter[2].g %10 ==0 && letter[2].b %10 ==0)){
   //Dynamically allocates or reallocates memory

    //Gets the last value of each pixel color and stores all 9 in an array
    for(int i = 0; i < 3; ++i){
      binaryLetter[(i * 3) + 0] = letter[i].r % 10;
      binaryLetter[(i * 3) + 1] = letter[i].g % 10;
      binaryLetter[(i * 3) + 2] = letter[i].b % 10;
      /*printf( "%d %d %d\t", binaryLetter[0], binaryLetter[1], binaryLetter[2]);
      printf( "%d %d %d\t", binaryLetter[3], binaryLetter[4], binaryLetter[5]);
      printf( "%d %d %d\n", binaryLetter[6], binaryLetter[7], binaryLetter[8]);*/


    }

    /*for(int i = 8; i > 0; --i){
      printf("%d\t",binaryLetter[i]);
      asciiVal = convertBinaryToChar(binaryLetter);
    }*/
    for(int i = 1; i < 9; ++i){
      if(binaryLetter[i] == 1){
        bitPos = 7 - (i - 1);
        asciiVal += (int)pow(2, bitPos);
      }
    }
    printf("%c", asciiVal);
  /*  for(int i = 1; i < 9; i){
      bitPos = 7 + (i-1);
      asciiVal += (int)pow(2, bitPos * binaryLetter[i]);
      printf("\n%d\n", asciiVal);
    }*/
    /*for(int i = 8; i >= 1;--i){
      bitPos = (8 - i);
      asciiVal += (int)pow(2, bitPos * binaryLetter[i]);
      printf("\n%d\n", asciiVal);
    }*/

    //Gets the ascii value of the set of binary numbers
    /*for(int i = 1; i < 9; ++i){
      if(binaryLetter[i] == '1'){
        bitPos = 8 - (i - 1);
        asciiVal = asciiVal + (int)pow(2, bitPos);

      }
    }*/
    //appends the character to the character array
    //message[strlen(message) - 1] = asciiVal;
    //printf("\n%c\t%d\t%ld\n", message[strlen(message) - 1], asciiVal, strlen(message));

    fscanf(in, "%c%c%c", &letter[0].r, &letter[0].g, &letter[0].b);
    fscanf(in, "%c%c%c", &letter[1].r, &letter[1].g, &letter[1].b);
    fscanf(in, "%c%c%c", &letter[2].r, &letter[2].g, &letter[2].b);
    asciiVal = 0;
    bitPos = 0;
  }
  //Frees memory for binary representation array and returns the completed
  //character array.
  free(letter);
}

/*int convertBinaryToChar(unsigned char list[]){
  int j = 0;
  int total = 0;
  for(int i = 9; i > 0; --i){
    total = total + pow(2,j * list[i]);
    ++j;
  }
  return total;
}*/
