
//BEGINNING OF ENCODEDECODE.H
#ifndef ENCODEDECODE_H
#define ENCODEDECODE_H
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include <math.h>
char* newMessage(char* message);
void printBoarder();
void printMessage(char* message);
void encode(char* message, FILE* in, FILE* out);
void decode(FILE* in);
void getMessage(FILE* in);
void menu();
int convertBinaryToChar(unsigned char list[]);
#endif

//END OF ENCODEDECODE.H
