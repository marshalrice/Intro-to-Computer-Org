#include "ppm.h"


header* readHeader(FILE* in){

  //Allocates memory for a header
  header* newHeader = (header*)malloc(sizeof(header));

  //Scans for header information and checks for comments
  fscanf(in, "%c%c", &newHeader->magicNum[0],&newHeader->magicNum[1]);
  fscanf(in, "%d", &newHeader->width);
  fscanf(in, "%d", &newHeader->height);
  fscanf(in, "%d\n", &newHeader->maxPixelVal);
  //End of header scanning

  //Returns newly created header
  return newHeader;
}
//END OF READHEADER FUNCTION



void writeHeadertoPPM(FILE* out, header* header){

  //Prints header information to an output PPM file
  fprintf(out, "%s\n", header->magicNum);
  fprintf(out, "%d\t", header->width);
  fprintf(out, "%d\t", header->height);
  fprintf(out, "%d\n", header->maxPixelVal);
  //End of header printing

}

void writeRestOfImage(char* message, FILE* in, FILE* out){
  /*rewind(in);
  header* temp = readHeader(in);
  pixel* buf = (pixel*)malloc((temp->width * temp->height) -
  (3 * strlen(message) * sizeof(pixel));
  fseek(in,sizeof(pixel)*3*strlen(message),SEEK_CUR);
  //fread(buf,(temp->width * temp->height) -
  (3 * strlen(message), in);
  //fwrite(,out);*/
}
//END OF WRITEHEADERTOPPM FUNCTION
