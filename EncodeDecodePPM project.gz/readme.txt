This project was a lot more time consuming than the first.
I spent a lot more time on this project than I should have.
However, with that being said, I don't think this lab added enough
newer information to be worth the assignment in my opinion. There are a
lot of repeated skills that, although I'm pretty just they're good
to reiterate, are not as beneficial than say a project on assembly code.
That would be fun, in my opinion. PA2, although showing some good skills,
just wasn't enough to be a big growth moment for me. I would've rather
had another lab than to do this big PA assignment. It would've saved
all of us time.
