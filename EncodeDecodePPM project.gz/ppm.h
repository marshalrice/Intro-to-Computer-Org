
//BEGINNING OF PPM.H
#ifndef PPM_H
#define PPM_H

//FUNCTION LIBRARY DECLARATIONS
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

//The header structure will hold the header data needed to create a PPM file
typedef struct Header{
  int width;
  int height;
  int maxPixelVal;
  char magicNum[2];
}header;

//The pixel structure will hold the red, green, and blue color values for an
//individual pixel in a PPM image
typedef struct Pixel{
  unsigned char r;
  unsigned char g;
  unsigned char b;
}pixel;

/*****************************************************************************
* Function: readHeader
*
* Function Description:
*   readHeader will take in a file and create a header pointer by scanning
*   the file and allocating memory for a header variable to store that
*   information. After storing is complete, a pointer to the newly
*   created header structure will be returned.
*
* Parameters:
*   FILE* in:
*     A file pointer to a ppm file that holds the header information and
*     pixel data.
*
* Return:
*   header*: A pointer to a header structure that holds information about
*     a PPM image.
*
*****************************************************************************/
header* readHeader(FILE* in);

/*****************************************************************************
* Function: writeHeadertoPPM
*
* Function Description:
*   This function prints header information from a header pointer to an output
*   file, which in this case, is a PPM file.
*
* Parameters:
*   FILE* out:
*     A PPM file to print header data to.
*
*   header* header: A pointer to a header structure of a image
*
* Return:
*   NONE
*
*****************************************************************************/
void writeHeadertoPPM(FILE* out, header* header);

/*****************************************************************************
* Function Description:
*   This function changes a PPM image's size given from input and creates
*   a new PPM file with the size transformations.
*
* Parameters:
*   FILE* in: the input PPM file where the original image is located
*
*   FILE* out: the output PPM file that'll hold the resized PPM image data.
*
* Return:
*   NONE
*
*****************************************************************************/
void writeRestOfImage(char* message, FILE* in, FILE* out);

#endif

//END OF PPM.H
