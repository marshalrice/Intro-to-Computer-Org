/*****************************************************************************
* Name: Marshal Rice
* CUID: C10291548
* Email: mrice4@clemson.edu
* Class: CPSC2310-002
* Instructor: Yvon Feaster
* Assignment: Programming Assignment 1
*
* File Description: FUNCTIONS.H
*   This header file creates a unified location for function calls for all
*   files that use this file as their header file. This file will be used in
*   FUNCTIONS.C and DRIVER.C for Programming Assignment 1.
*****************************************************************************/

//BEGINNING OF CODE

//HEADER GUARDS
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

//FUNCTION LIBRARY DECLARATIONS
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

//The header structure will hold the header data needed to create a PPM file
typedef struct Header{
  int width;
  int height;
  int maxPixelVal;
  char magicNum[2];
}header;

//The pixel structure will hold the red, green, and blue color values for an
//individual pixel in a PPM image
typedef struct Pixel{
  unsigned char r;
  unsigned char g;
  unsigned char b;
}pixel;

/*****************************************************************************
* Function: readHeader
*
* Function Description:
*   readHeader will take in a file and create a header pointer by scanning
*   the file and allocating memory for a header variable to store that
*   information. After storing is complete, a pointer to the newly
*   created header structure will be returned.
*
* Parameters:
*   FILE* in:
*     A file pointer to a ppm file that holds the header information and
*     pixel data.
*
* Return:
*   header*: A pointer to a header structure that holds information about
*     a PPM image.
*
*****************************************************************************/
header* readHeader(FILE* in);

/*****************************************************************************
* Function: writeHeadertoPPM
*
* Function Description:
*   This function prints header information from a header pointer to an output
*   file, which in this case, is a PPM file.
*
* Parameters:
*   FILE* out:
*     A PPM file to print header data to.
*
*   header* header: A pointer to a header structure of a image
*
* Return:
*   NONE
*
*****************************************************************************/
void writeHeadertoPPM(FILE* out, header* header);

/*****************************************************************************
* Function: checkComment
*
* Function Description:
*   This function checks for comments and disregards them when scanning in
*   information from a input file given.
*
* Parameters:
*   FILE* in: An input file that will be scanned for comments
*
* Return:
*   NONE
*
*****************************************************************************/
void checkComment(FILE* in);

/*****************************************************************************
* Function Description:
*   This function changes a PPM image's size given from input and creates
*   a new PPM file with the size transformations.
*
* Parameters:
*   FILE* in: the input PPM file where the original image is located
*
*   FILE* out: the output PPM file that'll hold the resized PPM image data.
*
* Return:
*   NONE
*
*****************************************************************************/
void resize(FILE* in, FILE* out);

/*****************************************************************************
* Function Description: negative
*   This function uses a PPM file to create a negative image, or an image
*   where each pixel is flipped in color from file input.
*
* Parameters:
*   FILE* in: The input file to the PPM image
*
*   FILE* out: the output file the negative PPM image will be printed to.
*
* Return:
*   NONE
*
*****************************************************************************/
void negative(FILE* in, FILE* out);

/*****************************************************************************
* Function Description: createImage
*   This function will allocate memory for a 2D array of pixels of size
*   width x height, which will be given from input.
*
* Parameters:
*   int width: the width of a PPM image
*
*   int height: the height of a PPM image
*
* Return:
*   pixel**: A double pointer to the newly allocated 2D array of pixels.
*
*****************************************************************************/
pixel** createImage(int width, int height);

/*****************************************************************************
* Function Description: getOldImage
*   This function will retrieve the original image data from an input file
*   and create a 2D array of the pixel data and return that image.
*
* Parameters:
*   FILE* in: The input PPM file
*
*   header* header: the PPM file header provided from the input file
*
* Return:
*   pixel**: A double pointer to the original image pixel data in the form
*     of a 2D array of pixels.
*
*****************************************************************************/
pixel** getOldImage(FILE* in, header* header);

/*****************************************************************************
* Function Description: freeImage
*   This function frees the image data along with its header.
*
* Parameters:
*   pixel** image: the 2D array pixel data of an image that will be freed.
*
*   header* header: the header data of the image provided from the parameter
*     that will also be freed from memory.
*****************************************************************************/
void freeImage(pixel** image, header* header);

/*****************************************************************************
* Function Description: getWidth
*   This function calculates the new width of the resized image by user input
*   and also checks that input data if it's a valid new width or not.
*
* Parameters:
*   int oldWidth: the width of the original image that will be used to create
*     the resized image.
*
* Return:
*   int: the validated width of the resized image
*****************************************************************************/
int getWidth(int oldWidth);

/*****************************************************************************
* Function Description: getHeight
*   This function calculates the new height of the resized image by user input
*   and also checks that input data if it's a valid new height or not.
*
* Parameters:
*   int oldHeight: the height of the original image that will be used to create
*     the resized image.
*
* Return:
*   int: the validated height of the resized image
*****************************************************************************/
int getHeight(int oldHeight);

/*****************************************************************************
* Function Description: getRelativeWidth
*   This function calculates the ratio from the old width to the new width
*
* Parameters:
*   int oldWidth: the width of the original image
*
*   int newWidth: the width of the resized image
*
* Return:
*   double: the ratio of the old width to the new width
*****************************************************************************/
double getRelativeWidth(int oldWidth, int newWidth);

/*****************************************************************************
* Function Description: getRelativeHeight
*   This function calculates the ratio from the old height to the new height
*
* Parameters:
*   int oldHeight: the height of the original image
*
*   int newHeight: the height of the resized image
*
* Return:
*   double: the ratio of the old height to the new height
*****************************************************************************/
double getRelativeHeight(int oldHeight, int newHeight);

/*****************************************************************************
* Function Desription: printImage
*   This function prints an image and its header to an out PPM file
*
* Parameters:
*   pixel** newImage: the 2D array image pixel data that will be printed
*
*   FILE* out: the outfile where the pixel data will be sent to.
*
*   header* header: the new image header that will be printed to the out PPM
*     file first.
*****************************************************************************/
void printImage(pixel** newImage, FILE* out, header* header);

/*****************************************************************************
* Function Description: imageTransformation
*   This function does the resizing tranformation via comparisons of each
*   pixel of the new image to the original image.
*
* Parameters:
*   pixel** oldImage: the old image pixel data in a 2D array format
*
*   pixel** newImage: the resized image pixel data in a 2D array format
*
*   header* oldHeader: the header data of the original image
*
*   header* newHeader: the header data of the new resized image
*
*   double relWidth: the ratio of the original and resized image widths
*
*   double relHeight: the ratio of the original and resized image heights
*
* Return:
*   pixel**: the proportional resized image based on the original image ratios
*
*****************************************************************************/
pixel** imageTransformation(pixel** oldImage, pixel** newImage,
  header* oldHeader, header* newHeader, double relWidth, double relHeight);


#endif
