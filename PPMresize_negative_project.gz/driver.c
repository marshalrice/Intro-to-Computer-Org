/*****************************************************************************
* Name: Marshal Rice
* CUID: C10291548
* Email: mrice4@clemson.edu
* Class: CPSC2310-002
* Instructor: Yvon Feaster
* Assignment: Programming Assignment 1
*
* File Description: DRIVER.C
*   This file will perform and return resizing and negative image
*   transformations from a PPM file given from input.
*
*****************************************************************************/

//BEGINNING OF DRIVER.C CODE

//Header declarations
#include "functions.h"


//BEGINNING OF MAIN FUNCTION
int main(int argc, char** argv){
  //checks if only one file was given as input
  assert(argc == 4);
  //opens the input file given from input
  FILE* in = fopen(argv[1], "r");
  FILE* resizeFP = fopen(argv[2], "w");
  FILE* negativeFP = fopen(argv[3], "w");
  //checks input file if it opened sucessfully
  assert(in != NULL);
  //calls the resizing of the input PPM file
  resize(in, resizeFP);
  //calls the negative imaging of the input PPM file
  negative(in, negativeFP);
  //closes the input file
  fclose(in);
  return 0;
}
//END OF MAIN FUNCTION


//END OF DRIVER.C CODE
