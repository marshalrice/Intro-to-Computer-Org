/*****************************************************************************
* Name: Marshal Rice
* CUID: C10291548
* Email: mrice4@clemson.edu
* Class: CPSC2310-002
* Instructor: Yvon Feaster
* Assignment: Programming Assignment 1
*
* File Description: FUNCTIONS.C
*   This file creates the function codes for all prototypes in header file
*   FUNCTIONS.H
*****************************************************************************/

#include "functions.h"

header* readHeader(FILE* in){

  //Allocates memory for a header
  header* newHeader = (header*)malloc(sizeof(header));

  //Scans for header information and checks for comments
  fscanf(in, "%c%c", &newHeader->magicNum[0],&newHeader->magicNum[1]);
  checkComment(in);
  fscanf(in, "%d", &newHeader->width);
  checkComment(in);
  fscanf(in, "%d", &newHeader->height);
  checkComment(in);
  fscanf(in, "%d\n", &newHeader->maxPixelVal);
  //End of header scanning

  //Returns newly created header
  return newHeader;
}
//END OF READHEADER FUNCTION



void writeHeadertoPPM(FILE* out, header* header){

  //Prints header information to an output PPM file
  fprintf(out, "%s\n", header->magicNum);
  fprintf(out, "%d\t", header->width);
  fprintf(out, "%d\t", header->height);
  fprintf(out, "%d\n", header->maxPixelVal);
  //End of header printing

}
//END OF WRITEHEADERTOPPM FUNCTION



void checkComment(FILE* in){
  //Creates a string long enough for a full line of code
  char checkChar[80];

  //Uses scanset to disregard everything except numbers
  //Header information after P6 should only be numbers so it stops when
  //header information or numbers are found.
  fscanf(in, "%[' ', a-z, A-Z, \n, #]", checkChar);
}
//END OF CHECKCOMMENT FUNCTION

void resize(FILE* in, FILE* out){
  //opens the out PPM file
  //sets file pointer to beginning of file
  rewind(in);

  //getting the old image header information and declaring a new header for
  //the new resized image
  header* oldHeader = readHeader(in);
  header* newHeader = (header*)malloc(sizeof(header));

  //getting the new width and height for the resized image to put into
  //the new image header
  int newWidth = getWidth(oldHeader->width);
  int newHeight = getHeight(oldHeader->height);

  //new image header declaration
  newHeader->width = newWidth;
  newHeader->height = newHeight;
  newHeader->maxPixelVal = oldHeader->maxPixelVal;
  newHeader->magicNum[0] = oldHeader->magicNum[0];
  newHeader->magicNum[1] = oldHeader->magicNum[1];

  //calculating the ratios of the old image's width and height to the
  //new image's width and height respectively
  double relWidth = getRelativeWidth(oldHeader->width, newWidth);
  double relHeight = getRelativeHeight(oldHeader->height, newHeight);

  //allocating 2D memory for the new image and getting the old image
  //pixel data and also storing it in a 2D array of pixels
  pixel** newImage = createImage(newWidth, newHeight);
  pixel** oldImage = getOldImage(in, oldHeader);

  //resizing the old image and storing it in a new resized image
  newImage = imageTransformation(oldImage, newImage, oldHeader, newHeader,
    relWidth, relHeight);
  //printing the new resized image and header
  writeHeadertoPPM(out, newHeader);
  printImage(newImage, out, newHeader);

  //freeing all memory used for both the old and new images along with their
  //respective headers
  freeImage(oldImage, oldHeader);
  freeImage(newImage, newHeader);
  fclose(out);
}


void negative(FILE* in, FILE* out){
  //setting input file pointer to beginning of file
  rewind(in);
  //declaring a new out file to print the negative image to.
  //declaring pixel values
  unsigned char r, g, b;
  //getting the old image header data
  header* header = readHeader(in);
  //writing the old image header data to the negative file since no change
  //in amount of pixels for the new image. Only each pixel is being changed.
  writeHeadertoPPM(out, header);
  //changing each individual pixel color information and writing it to the
  //out file
  for(int i = 0; i < header->width * header->height; ++i){
      fscanf(in, "%c%c%c", &r, &g, &b);
      r = 255 - r;
      g = 255 - g;
      b = 255 - b;
      fprintf(out, "%c%c%c", r, g, b);
  }
  //closing the out file
  fclose(out);
}
//END OF NEGATIVE FUNCTION

//BEGINNING OF CREATE IMAGE FUNCTION
pixel** createImage(int width, int height){
  //2D memory allocation of a new image
  pixel** newImage = (pixel**)malloc(height * sizeof(pixel*));
  for(int i = 0; i < height; ++i){
    newImage[i] = (pixel*)malloc(width * sizeof(pixel));
  }
  //returns a newly allocated 2D array of pixels
  return newImage;
}
//END OF CREATE IMAGE FUNCTION

//BEGINNING OF FREE IMAGE FUNCTION
void freeImage(pixel** image, header* header){
  //loops through each pixel pointer and frees its memory before it frees
  //the entire array
  for(int i = 0; i < header->height; ++i){
    free(image[i]);
  }
  //frees the entire 2D array
  free(image);
  //frees the image's header data
  free(header);
}
//END OF FREE IMAGE FUNCTION


//BEGINNING OF GETWIDTH FUNCTION
int getWidth(int oldWidth){
  //new width declaration
  int newWidth;
  //prompts user to enter a new valid width
  printf("Please enter the new width addition/reduction. It must be within"
    "-100 to 100: ");
  scanf("%d", &newWidth);
  //continuously asks for valid input if initially incorrect
  while((newWidth < -100 || newWidth > 100) ||
    (oldWidth + newWidth <= 0)){
    fprintf(stderr, "ERROR! Invalid input for new width. Try Again.\n");
    scanf("%d", &newWidth);
  }
  //returns the newly adjusted width
  return newWidth + oldWidth;
}
//END OF GETWIDTH FUNCTION


//BEGINNING OF GETHEIGHT FUNCTION
int getHeight(int oldHeight){
  //new height declaration
  int newHeight;
  //prompts user for new height
  printf("Please enter the new height addition/reduction. It must be within"
    "-100 to 100: ");
  scanf("%d", &newHeight);
  //continuously asks for valid height if initially incorrect
  while((newHeight < -100 || newHeight > 100) ||
    (oldHeight + newHeight <= 0)){
    fprintf(stderr, "ERROR! Invalid input for new height. Try Again.\n");
    scanf("%d", &newHeight);
  }
  //returns the newly adjusted height
  return newHeight + oldHeight;
}
//END OF GETHEIGHT FUNCTION


//BEGINNING OF GETRELATIVEWIDTH FUNCTION
double getRelativeWidth(int oldWidth, int newWidth){
  //divides the old width by the new and returns that ratio as a double
  return ((double)oldWidth / newWidth);
}
//END OF GETRELATIVEWIDTH FUNCTION


//BEGINNING OF GETRELATIVEHEIGHT FUNCTION
double getRelativeHeight(int oldHeight, int newHeight){
  //divides the old height by the new and returns that ratio as a double
  return ((double)oldHeight / newHeight);
}
//END OF GETRELATIVEHEIGHT FUNCTION


//BEGINNING OF GETOLDIMAGE FUNCTION
pixel** getOldImage(FILE* in, header* header){
  pixel** oldImage = createImage(header->width, header->height);
  for(int i = 0; i < header->height; ++i){
    for(int j = 0; j < header->width;++j){
      fscanf(in, "%c%c%c", &oldImage[i][j].r, &oldImage[i][j].g,
      &oldImage[i][j].b);
    }
  }
  return oldImage;
}
//END OF GETOLDIMAGE FUNCTION


//BEGINNING OF PRINTIMAGE FUNCTION
void printImage(pixel** newImage, FILE* out, header* header){
  for(int i = 0; i < header->height; ++i){
    for(int j = 0; j < header->width; ++j){
      fprintf(out, "%c%c%c", newImage[i][j].r, newImage[i][j].g,
      newImage[i][j].b);
    }
  }
}
//END OF PRINTIMAGE FUNCTION


//BEGINNING OF IMAGETRANSFORMATION FUNCTION
pixel** imageTransformation(pixel** oldImage, pixel** newImage, header* oldHeader,
  header* newHeader, double relWidth, double relHeight){
  for(int i = 0; i < newHeader->height; ++i){
    for(int j = 0; j < newHeader->width; ++j){
      newImage[i][j] = oldImage[(int)(i * relHeight)][(int)(j * relWidth)];
    }
  }
  return newImage;
}
//END OF IMAGETRANSFORMATION FUNCTION


//END OF FUNCTIONS.C CODE
