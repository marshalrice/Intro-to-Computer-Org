Things I liked about the project: It allowed me to use multiple things covered
in the notes. I liked understanding how to output two files when normally
we'd only output to one file. The complexity was a nice increase. I also liked
the timing of the project due date. This is a great time because in the next
couple of weeks students will be slam packed with exams. Sunday due date,
however, I didn't like. Mondays or Tuesdays are good for projects because we
can get in to office hours before the due date. Sunday, however, is not
possible, so people are left with final code mistakes. Not major mistakes like
segmentation-faults but major cosmetic mistakes like their picture not being
printed properly or it being skewed or not being able to perform multiple
transformations at a time.

Things I did not like about the project: The notes did not cover common issues
that the resize function poses. Also, the example files don't have memory
allocation or comment delimited code. The only thing present in the files were
numbers typed. Those files and the slides weren't helpful in fixing my code.
